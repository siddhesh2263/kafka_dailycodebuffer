package com.example.cab_book_user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabBookUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
